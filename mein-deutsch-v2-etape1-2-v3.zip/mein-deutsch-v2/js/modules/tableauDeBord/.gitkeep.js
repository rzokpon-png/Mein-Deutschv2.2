// Étape à venir — module « tableauDeBord » (contenu et logique ajoutés à l'étape correspondante du plan de développement)
