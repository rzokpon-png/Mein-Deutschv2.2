// Étape à venir — module « conjugaison » (contenu et logique ajoutés à l'étape correspondante du plan de développement)
