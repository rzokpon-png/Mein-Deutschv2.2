// Étape à venir — module « dictionnairePersonnel » (contenu et logique ajoutés à l'étape correspondante du plan de développement)
