// Étape à venir — module « vocabulaire » (contenu et logique ajoutés à l'étape correspondante du plan de développement)
