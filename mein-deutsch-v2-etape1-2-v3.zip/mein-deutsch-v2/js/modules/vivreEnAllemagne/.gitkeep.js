// Étape à venir — module « vivreEnAllemagne » (contenu et logique ajoutés à l'étape correspondante du plan de développement)
