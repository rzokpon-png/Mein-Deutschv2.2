// Étape à venir — module « phonetique » (contenu et logique ajoutés à l'étape correspondante du plan de développement)
